/**
 * 
 */
/**
 * 
 */
module Number_Game {
}