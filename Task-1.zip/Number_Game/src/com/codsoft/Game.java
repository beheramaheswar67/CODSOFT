package com.codsoft;
import java.util.Random;
import java.util.Scanner;

public class Game {
	int InputNumber;
	int number;
	int GuessesOfNum;
	int Attempts = 4;
	Scanner sc = new Scanner(System.in);
	
	public int getGuessesOfNum() {
		return GuessesOfNum;
	}
	public void setGuessesOfNum(int guessesOfNum) {
		GuessesOfNum = guessesOfNum;
	}
	
	Game(){
		Random rnd = new Random();
		this.number=rnd.nextInt(100)+1; //Here i specified range 1 to 100
	}
	
	void TakeUserInput() {
		System.out.print("Guessthe Number? : ");
		InputNumber= sc.nextInt();
	}
	
	boolean IsCorrectNumber() {
		GuessesOfNum++;
		if(number == InputNumber) {
			System.out.println("Yes you guessed Right, You guessed it in: "+ number + " Attempt: "+ GuessesOfNum);
			//System.out.println("Yes! You guessed it right in " + GuessesOfNum + " attempts.");
			return true;
		} 
		else if (InputNumber < number){
			System.out.println("Attempts left: " + Attempts);
			System.out.println("Too low");
		}
		else if(InputNumber > number) {
			System.out.println("Attempts left: " + Attempts);
			System.out.println("Too high");
		}
		Attempts--;
		return false;
		
	     } 
	
	int getGuesses() {
		return GuessesOfNum;
	}
}
