package com.codsoft;

import java.util.Scanner;

public class Number_Game {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int RoundWon = 0;
		int TotalRound = 0;
		int score = 0;

		System.out.println("Welcome to Number Game !");
		System.out.println("You have '5' attempts to guess the number.");

		boolean Start = true;

		while (Start) {
			Game game = new Game();
			TotalRound++;

			int MaxAttempt = 5;
			boolean correct = false;

			while (MaxAttempt > 0 && !correct) {
				game.TakeUserInput();
				correct = game.IsCorrectNumber();
				MaxAttempt--;
				if (MaxAttempt == 0) {
					System.out.println("\nGame Over");
				}
			}

			if (correct) {
				score += 10;
				RoundWon++;
			} else {
				System.out.println("Your Score is: " + score);
			}

			System.out.print("\nDo you want to Play Again? (yes/no): ");
			String choice = sc.nextLine();

			if (choice.equalsIgnoreCase("yes")) {
				Start = true;
			} else if (choice.equalsIgnoreCase("no")) {
				Start = false;
			}
		}

		System.out.println("\nGame Over");
		System.out.println("Total Round Playes: " + TotalRound);
		System.out.println("Total Round Won: " + RoundWon);
		System.out.println("Your Score is: " + score);
	}

}
